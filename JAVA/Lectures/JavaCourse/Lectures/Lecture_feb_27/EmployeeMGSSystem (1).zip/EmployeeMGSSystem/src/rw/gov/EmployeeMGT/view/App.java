
package rw.gov.EmployeeMGT.view;

import java.util.Scanner;
import rw.gov.EmployeeMGT.dao.EmployeeDao;
import rw.gov.EmployeeMGT.model.Employee;

/**
 *
 * @author muganga
 */
public class App {
    public static void main(String[] args) {
        // variable declaration
        boolean condition = true;
        int empId;
        String empNames;
        Scanner sc = new Scanner(System.in);
        while(condition){
            System.out.println("=================");
            System.out.println("1. Register Employee");
            System.out.println("2. Register Employee By Prepared!");
            System.out.println("0. Exit");
            System.out.println("------------");
            System.out.println("Choose: ");
            int choice = sc.nextInt();
            switch(choice){
                case 1:
                    System.out.println("Enter  Employee ID: ");
                    empId = sc.nextInt();
                    System.out.println("Enter Employee Name: ");
                    empNames = sc.next();
                    // calling model class
                    Employee emp = new Employee();
                    emp.setEmployeeId(empId);
                    emp.setEmployeeName(empNames);
                    
                    //calling DAO
                    EmployeeDao dao = new EmployeeDao();
                    dao.registerEmployee(emp);
                    condition = toContinue();
                    break;
                case  2:
                    System.out.println("Enter  Employee ID: ");
                    empId = sc.nextInt();
                    System.out.println("Enter Employee Name: ");
                    empNames = sc.next();
                    // calling model class
                    emp = new Employee();
                    emp.setEmployeeId(empId);
                    emp.setEmployeeName(empNames);
                    
                    //calling DAO
                    dao = new EmployeeDao();
                    dao.registerEmployeeByPreparedStatment(emp);
                    condition = toContinue();
                    break;
                case 0:
                    System.out.println("Thank you for Using the System!");
                    System.exit(0);
                default:
                    System.out.println("Wrong Choice!");
                    System.out.println("Enter Yes to continue or no to quit!");
                    String answer = sc.next();
                    if(answer.equalsIgnoreCase("yes")){
                        condition = true;
                    }else{
                        System.out.println("Thank you for using the system!");
                        condition = false;
                    }
            }
        }
    }
    
    private static boolean toContinue(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Yes to continue or no to quit!");
        String answer = sc.next();
        if(!answer.equalsIgnoreCase("yes")){
            return false;
        }
        return true;
    }
}
