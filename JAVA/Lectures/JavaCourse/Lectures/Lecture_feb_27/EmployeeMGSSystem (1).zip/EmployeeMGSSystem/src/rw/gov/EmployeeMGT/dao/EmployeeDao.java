
package rw.gov.EmployeeMGT.dao;

import java.sql.*;
import rw.gov.EmployeeMGT.model.Employee;

/**
 *
 * @author muganga
 */
public class EmployeeDao {
    // Global variable declaration
    private String jdbcUrl  =  "jdbc:postgresql://localhost:5432/java_2024_wednesday";
    private String dbUsername = "postgres";
    private String dbPasswd = "Welcome@123";
    // CRUD Operation
    //Create Operation
    
    public void registerEmployee(Employee empObj){
        // surround with try and catch
        try{
            // create connection
            Connection con = DriverManager.getConnection(jdbcUrl, dbUsername,dbPasswd);
            // create statement
            Statement st = con.createStatement();
            // execute statement
            String sql = "INSERT INTO employee (emp_id,emp_names) values("+empObj.getEmployeeId()+",'"+empObj.getEmployeeName()+"')";
            int rowAffected = st.executeUpdate(sql);
            if(rowAffected > 0){
                System.out.println("Data Saved!");
            }else{
                System.out.println("Data Not Saved!");
            }
            // close connection
            con.close();
            
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }
    
    public void registerEmployeeByPreparedStatment(Employee empObj){
        // surround with try and catch
        try{
            // create connection
            Connection con = DriverManager.getConnection(jdbcUrl, dbUsername,dbPasswd);
            //  Prepare Statement
            String sql = "INSERT INTO employee (emp_id,emp_names) values(?,?)";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setInt(1, empObj.getEmployeeId());
            pst.setString(2, empObj.getEmployeeName());
            // excute the query
            int rowAffected = pst.executeUpdate();
            if(rowAffected > 0){
                System.out.println("Data Saved!");
            }else{
                System.out.println("Data Not Saved!");
            }
            // close connection
            con.close();
            
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }
    
}
